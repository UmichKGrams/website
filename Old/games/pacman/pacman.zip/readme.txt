to install follow these steps:

- extract all the files to a single directory (for example "pacgame")
- start your browser (no need to be connected)
- select the menu "file" then the menu "open"
- choose "browse" and go the "pacgame" directory
- select the file "pac.html" and click ok

the game start in your browser.

for additional questions mailto: buisson3@cuimail.unige.ch

the game is free for individuals and there is a non exclusive
paid up licence for companies (contact me)

Enjoy!

Jean-Francois Buisson
Student in computer science 
University of Geneva (CH)

http://cuiwww.unige.ch/~buisson3