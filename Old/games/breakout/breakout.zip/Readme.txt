Breakout is my small contribution to the world wide web community.
Permission to host the game on your site (personal or commercial), is hereby
granted without restrictions.

The following files that make up the game were written by me (Louis Schiano):
breakout.java
Ball2.java 
Paddle.java 
Block.java 

Check out the source code to breakout here:
http://www.freeapplet.com/Breakout.html

Please visit my home page here:
http://www.freeapplet.com

Email me here:
lschian@mindspring.com

Special thanks to AMI for the Fireworks applet:
Fireworks.java

Visit AMI's homepage here:
http://www.j-link.or.jp/~rlee

Email AMI here:
rlee@j-link.or.jp
